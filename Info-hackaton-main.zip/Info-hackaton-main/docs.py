### Données d'entraînement du modèle, à ne pas modifier
notes_ex1_path = "Exemple 1/Exemple 1 - notes FC.docx"
devis_ex1_path = "Exemple 1/20250631-Client-Sujet-Devis exemple 1.xlsx"
prop_ex1_path = "Exemple 1/20250631-Gjoa-Sujet-Proposition.docx"

notes_ex2_path = "Exemple 2/Exemple 2 - notes FC.docx"
devis_ex2_path = "Exemple 2/20250401-Devis-Client-Exemple 2.xlsx"
prop_ex2_path = "Exemple 2/20250402-Gjoa-Client-Exemple 2-Proposition.docx"

reference = "reference.xlsx"


template_path = "Template.docx"
template_mod_path = "Template_mod.docx"
template_Note_path='template_notes.docx'




### Voici la zone où vous pouvez apporter des modifications:


test_notes_path = "Test_Notes.docx"                                     #Lien vers les notes prises pendant l'entretien
devis_3_path = "Test/20250515-Devis-client-projet.xlsx"                 #Lien vers le devis proposé à l'entreprise cliente
sortie_path = "contrat.docx"                                            #Lien de sortie souhaité pour le devis