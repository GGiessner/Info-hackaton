from insere_text import main
main()